package cn.yehongqi.myintent;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterActivity extends Activity {
	static String password1;
	private String password2;
	private String name;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_register);

		final EditText et_register_name = (EditText) findViewById(R.id.et_register_name);
		final EditText et_register_password = (EditText) findViewById(R.id.et_register_password);
		final EditText et_register_passworda = (EditText) findViewById(R.id.et_register_passworda);
		Button bt_register_register = (Button) findViewById(R.id.bt_register_register);

		bt_register_register.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				name = et_register_name.getText().toString().trim();
				password1 = et_register_password.getText().toString().trim();
				password2 = et_register_passworda.getText().toString().trim();

				if (password1.equals("") || password2.equals("") || name.equals("")) {
					Toast.makeText(RegisterActivity.this, "�û���������.ȷ�����벻��Ϊ�գ�", 1).show();
				} else if (!password1.equals(password2)) {
					Toast.makeText(RegisterActivity.this, "������ȷ�����벻һ�£�", 1).show();
				} else if (password1.equals(password2)) {
					Intent data = new Intent();
					data.putExtra("name", name);
					data.putExtra("password", password1);
					setResult(RESULT_OK, data);
					finish();
				}
			}
		});
	}
}
