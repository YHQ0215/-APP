package cn.yehongqi.myintent;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

	protected static final int REGISTER = 0;
	private String name;
	private String passworld;
	private EditText et_main_name, et_main_password;
	private ImageView logo;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		et_main_name = (EditText) findViewById(R.id.et_main_name);
		Button bt_main_login = (Button) findViewById(R.id.bt_main_login);
		TextView tv_main_register = (TextView) findViewById(R.id.tv_main_register);
		et_main_password = (EditText) findViewById(R.id.et_main_password);
		logo = (ImageView) findViewById(R.id.logo);

		
		bt_main_login.setBackgroundColor(Color.parseColor("#FF9800"));
		bt_main_login.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				String main_password = et_main_password.getText().toString().trim();
				String main_name = et_main_name.getText().toString().trim();
				if (main_name.equals("") || main_password.equals("")) {
					Toast.makeText(MainActivity.this, "�û��������벻��Ϊ�գ�", 1).show();
				} else if (!main_password.equals(RegisterActivity.password1)) {
					Toast.makeText(MainActivity.this, "�û�������������", 1).show();
				} else if (main_password.equals(RegisterActivity.password1)) {
					String input_name = et_main_name.getText().toString().trim();
					Intent intent = new Intent(MainActivity.this, WelcomeActivity.class);
					intent.putExtra("name", input_name);
					startActivity(intent);
					finish();
				}
			}
		});

		tv_main_register.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(MainActivity.this, RegisterActivity.class);
				startActivityForResult(intent, REGISTER);
			}
		});
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		if (requestCode == REGISTER) {
			if (resultCode == RESULT_OK) {// �û����ص�������������ģ���Ȼ����ֱ��ȥȡ����Ҳ�ǿ��Եģ�������
				name = data.getStringExtra("name");
				passworld = data.getStringExtra("password");
				et_main_name.setText(name);
			}
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
